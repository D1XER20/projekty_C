#include <targets\AT91SAM7.h>  
#include "pcf8833u8_lcd.h"    
#include <stdio.h>

#define PUSH PIOB_SODR_P24
#define BACK PIOB_SODR_P25
#define JOY_UP PIOA_SODR_P9
#define JOY_PUSH PIOA_SODR_P15
#define JOY_LEFT PIOA_SODR_P7
#define JOY_DOWN PIOA_SODR_P8
#define JOY_RIGHT PIOA_SODR_P14
 


typedef struct menu_struct menu_t;

struct menu_struct 
{
  const char * name;
  menu_t * next; // Next
  menu_t * prev; // Previous 
  menu_t * child; 
  menu_t * parent; 
  void( * menu_function)(void);
};

void drawBoard(){
  LCDSetLine(2,2, 126, 2, BLACK);     //Pionowa 1
  LCDSetLine(3, 3, 127, 3, BLACK);
  LCDSetLine(4, 4, 128, 4, BLACK);

  LCDSetLine(2, 2, 2, 126, BLACK);     //Pionowa 1
  LCDSetLine(3, 3, 3, 127, BLACK);
  LCDSetLine(4, 4, 4, 128, BLACK);

  LCDSetLine(2, 126, 126, 126, BLACK);     //Pionowa 1
  LCDSetLine(3, 127, 127, 127, BLACK);
  LCDSetLine(4, 128, 128, 128, BLACK);

  LCDSetLine(126, 128, 126, 2, BLACK);     //Pionowa 1
  LCDSetLine(127, 127, 127, 3, BLACK);
  LCDSetLine(128, 126, 128, 4, BLACK);

  
}

menu_t  menu_1,  menu_2,  menu_3,  sub_menu_1_1,  sub_menu_1_2, sub_menu_2_1, sub_menu_2_2, sub_menu_3_1, sub_menu_3_2;

menu_t menu_1 = {
 "MENU 1 ", 
 & menu_2, 
 & menu_1, 
 & sub_menu_1_1,
 NULL,
 NULL
};

menu_t sub_menu_1_1 = {
 "PROGRAM 1",
 & sub_menu_1_2,
 & sub_menu_1_1,
 NULL,
& menu_1,
NULL
};

menu_t sub_menu_1_2 = {
 "PROGRAM 2",
 NULL,
 & sub_menu_1_1,
 NULL,
 & menu_1,
 NULL
};

menu_t menu_2 = {
 "MENU 2 ",
 & menu_3,
 & menu_1,
 & sub_menu_2_1,
 NULL,
NULL };

menu_t sub_menu_2_1 = {
 "PROGRAM 1",
 & sub_menu_2_2,
 & sub_menu_2_1,
 NULL,
 & menu_2,
 NULL
};

menu_t sub_menu_2_2 = {
 "PROGRAM 2",
 NULL,
  & sub_menu_2_1,
 NULL,
 & menu_2,
 NULL
};

menu_t menu_3 = {
 "MENU 3 ",
 NULL,
 & menu_2,
 & sub_menu_3_1,
 NULL,
NULL };

menu_t sub_menu_3_1 = {
 "PROGRAM 1 ",
 & sub_menu_3_2,
 & sub_menu_3_1,
 NULL,
 & menu_3,
 NULL
};

menu_t sub_menu_3_2 = {
 "MENU 1 ",
 NULL,
 & sub_menu_3_1,
 & sub_menu_1_1,
 & menu_3,
 NULL
};



void displayName(menu_t *menu, menu_t *curr, const unsigned char pos) 
{
    if (menu->name[0] == curr->name[0]) 
    {
        LCDPutStr((char *) menu->name, pos, 5, MEDIUM, BLACK, GREEN);
        return;
    }
    LCDPutStr((char *) menu->name, pos, 5, MEDIUM, BLACK, WHITE);
}

void Strzawka(int pos){
 int x;
 switch (menu) {
   case 1: x = 50; break;
   case 2: x = 70; break;
   case 3: x = 90; break;
 }
 LCDPutChar('<', x, POINTER_Y+10, SMALL, BLACK, WHITE);
}

void printMenu(menu_t *menu, menu_t *curr) 
{
    LCDClearScreen();
    drawBoard();
    LCDPutStr("Zachatka Ivan",10,10,SMALL,BLACK,WHITE);
    LCDPutStr("Laboratorium ",95,15,SMALL,BLACK,WHITE);
    LCDPutStr("systemow wbudowanych",110,10,SMALL,BLACK,WHITE);
    if (curr == NULL) 
    {
        return;
    }
    unsigned char pos = 30;
    while (menu != NULL) 
    {
        displayName(menu, curr, pos);
        kursor1();
        pos += 20;
        menu = menu->next;
        if ((PIOA_PDSR & JOY_DOWN)==0)
        {
          LCDSetRect(25,75,35,90,FILL,WHITE);
          kursor2();
        }
        if ((PIOA_PDSR & JOY_UP)==0)
        {
          LCDSetRect(45,75,60,90,FILL,WHITE);
          kursor1();
        }
         
    }
}

void changeSelect(menu_t **menu, menu_t *sel) 
{
    if (sel == NULL) 
    {
        return;
    }
    *menu = sel;
}

void put(menu_t *menu) {

LCDPutStr(menu->name, 50, 10, SMALL, BLACK, WHITE);}

int main ()
{
    PMC_PCER = PMC_PCER_PIOA;
    PMC_PCER = PMC_PCER_PIOB;
    InitLCD();
    SetContrast(45);
    menu_t *currentPointer = &menu_1; // Aktualny wska�nik
    menu_t *selected = currentPointer;
    printMenu(currentPointer, selected);
    char ismenu = 0;
    drawBoard();
    LCDPutStr("Zachatka Ivan",10,10,SMALL,BLACK,WHITE);
    LCDPutStr("Laboratorium ",95,15,SMALL,BLACK,WHITE);
    LCDPutStr("systemow wbudowanych",110,10,SMALL,BLACK,WHITE);
  while(1)
  { 
        if (!(PIOB_PDSR & BACK)) 
        {
            if (selected->menu_function != NULL) 
            {
                selected->menu_function();
                ismenu = 1;
            }
            if (selected->child != NULL) 
            {
                currentPointer = currentPointer->child;
                selected = currentPointer;
                printMenu(currentPointer, selected);
            }
            while (!(PIOB_PDSR & BACK))
            {
                continue;
            }
        }
        if (!(PIOB_PDSR & PUSH)) 
        {
            if (currentPointer->parent != NULL && ismenu == 0) 
            {
                currentPointer = currentPointer->parent;
                selected = currentPointer;
                printMenu(currentPointer, selected);
            }
            if (ismenu == 1) 
            {
                ismenu = 0;
                printMenu(currentPointer, selected);
            }
            while (!(PIOB_PDSR & PUSH)) 
            {
                continue;
            }
        }
    }
}