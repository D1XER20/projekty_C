#include <targets\AT91SAM7.h>
#include "pcf8833u8_lcd.h"
#include <stdio.h>
#include <stdint.h>
#define SW_1 PIOB_SODR_P24 // zdefiniowanie portu odpowiadajacego za przycisk SW_1
#define SW_2 PIOB_SODR_P25  // zdefiniowanie portu odpowiadajacego za przycisk SW_2
#define LCD_BACKLIGHT PIOB_SODR_P20 // zdefiniowanie portu odpowiadajacego za podswietlenie LCD
#define JOY_UP   PIOA_SODR_P9 // zdefiniowanie portu odpowiadajacego za joystick skierowany w gore JOY_UP
#define JOY_ENTER  PIOA_SODR_P15 // zdefiniowanie portu odpowiadajacego za joystick wcisniety JOY_ENTER
#define JOY_LEFT  PIOA_SODR_P7  // zdefiniowanie portu odpowiadajacego za joystick skierowany w lewo JOY_LEFT
#define JOY_DOWN  PIOA_SODR_P8  // zdefiniowanie portu odpowiadajacego za joystick skierowany w dol JOY_DOWN 
#define JOY_RIGHT  PIOA_SODR_P14  // zdefiniowanie portu odpowiadajacego za joystick skierowany w prawo JOY_RIGHT


// Interfejs
typedef struct menu_struct menu_t;

struct menu_struct {
const char * name; // Nazwa elementu
menu_t * next; // Nastepny element
menu_t * prev; // Poprzedni element
menu_t * child; // Dziecko danego wskaznika
menu_t * parent; // Rodzic danego wskaznika
void( * menu_function)(void); // Funkcja wskaznikowa
};

menu_t menu_1, menu_2, menu_3, sub_menu_1_1, sub_menu_1_2, sub_menu_2_1, sub_menu_2_2, sub_menu_3_1, sub_menu_3_2;

// Definicje komponentow menu
menu_t menu_1 = {
"MENU 1 ",
& menu_2,
& menu_1,
& sub_menu_1_1,
NULL,
NULL
};

menu_t sub_menu_1_1 = {
"FUNKCJA 1 ",
& sub_menu_1_2,
& sub_menu_1_1,
NULL,
& menu_1,
NULL
};


menu_t sub_menu_1_2 = {
"FUNKCJA 2 ",
NULL,
& sub_menu_1_1,
NULL,
& menu_1,
NULL
};

menu_t menu_2 = {
"MENU 2 ",
& menu_3,
& menu_1,
& sub_menu_2_1,
NULL,
NULL
};

menu_t sub_menu_2_1 = {
"FUNKCJA 1 ",
& sub_menu_2_2,
& sub_menu_2_1,
NULL,
& menu_2,
NULL
};

menu_t sub_menu_2_2 = {
"FUNKCJA 2 ",
NULL,
& sub_menu_2_1,
NULL,
& menu_2,
NULL
};

menu_t menu_3 = {
"MENU 3 ",
NULL,
& menu_2,
& sub_menu_3_1,
NULL,
NULL
};

menu_t sub_menu_3_1 = {
"FUNKCJA 1 ",
& sub_menu_3_2,
& sub_menu_3_1,
NULL,
& menu_3,
NULL
};

menu_t sub_menu_3_2 = {
"MENU 1 ",
NULL,
& sub_menu_3_1,
& sub_menu_1_1,
& menu_3,
NULL
};

menu_t * currentPointer = & menu_1; // Aktualny wska�nik    
uint8_t menu_cursor; // Nr aktualnie wybranego elementu na danym poziomie
uint8_t lcd_row_pos; // Numer pozycji menu naLCD
uint8_t lcd_row_pos_level_1, lcd_row_pos_level_2; //  Numer pozycji menu naLCD dla ni�szych poziom�w
int tempIndex;//wspomocniczy element dla wejscia i wyjscia

void pokazInt()
{
  menu_t *t; // wskaznik pomocniczy do przechowywania adresow
  int width; // zmienna pomocnicza do ukladu elementow

  if (currentPointer->parent)// Jesli to menu nadrzedne
  {
    width = 115; // Ustawienie odpowiedniego wymiaru
    t = (currentPointer->parent)->child; // wskaznik pomocniczy ustawiony na dziecko danego elementu
  }
  else //dla podmenu
  {
    width = 75; // Ustawienie odpowiedniego wymiaru
    t = &menu_1; // wskaznik pomocniczy ustawiony na pierwszy element menu glownego
  }

  LCDClearScreen(); // Czyszczenie ekranu
  LCDEkranMenu(); // Przygotowanie ekranu pod interfejs(w pliku pcf8833u8_lcd.c)
  // Elementy interfejsu
  LCDSetRect(5, 5, 127, 127, '0', BLACK); 
  LCDPutStr("Ivan Zachatka", 10, 10, MEDIUM, BLACK, GREEN);
   LCDPutStr("s96532", 20, 10, MEDIUM, BLACK, GREEN);
  LCDPutStr("Laboratorium ", 105, 10, SMALL, BLACK, GREEN);
  LCDPutStr("systemy wbudowane", 115, 10, SMALL, BLACK, GREEN); 

  LCDPutStr("MENU 1", 45, 20, MEDIUM, BLACK, YELLOW);
  LCDPutStr("MENU 2", 60, 20, MEDIUM, BLACK, YELLOW);
  LCDPutStr("MENU 3", 75, 20, MEDIUM, BLACK, YELLOW);

  // Rysowanie kursora w odpowiednim miejscu
  int i;
  int height = 45;
  int wForCursor = 20;
  if (width != 75){
    for(i=0; i<2; i++){ // Dla podmenu
      LCDPutStr(t->name, height, wForCursor, MEDIUM, BLACK, YELLOW); // "t->name" - wykorzystanie nazw komponentow zdefiniowanych powyzej
      if(menu_cursor == i){
        LCDPutStr("<", height, width, MEDIUM, BLACK, YELLOW);
      }
      height += 15;
      t = t->next;
    }
  }
  else{
    for(i=0; i<3; i++){ // Dla menu glownego
      LCDPutStr(t->name, height, wForCursor, MEDIUM, BLACK, YELLOW); 
      if(menu_cursor == i){
        LCDPutStr("<", height, width, MEDIUM, BLACK, YELLOW);
      }
      height += 15;
      t = t->next;
    }
  }
}

void odswInt() // odswiezanie - analogicznie do funkcji 'showInterface'
{
  menu_t *t;
  int width;

  if(currentPointer->parent)
  {
    width = 115;
    t = (currentPointer->parent)->child;
  }
  else{//dla podmenu
    width = 75;
    t = &menu_1;
  }
  LCDClearScreenMenuApp();//w pliku pcf8833u8_lcd.c
  //kursor
  int i;
  int height = 40;
  int wForCursor = 20;
  if (width != 75){
    for(i=0; i<2; i++){//dla podmenu
      LCDPutStr(t->name, height, wForCursor, MEDIUM, BLACK, YELLOW);
      if(menu_cursor == i){
        LCDPutStr("<",height, width, MEDIUM, BLACK, YELLOW);
      }
      height += 15;
      t = t->next;
    }
  }
  else{
    for(i=0; i<3; i++){//dla menu g��wnego 
      LCDPutStr(t->name, height, wForCursor, MEDIUM, BLACK, YELLOW);
      if(menu_cursor == i){
        LCDPutStr("<",height, width, MEDIUM, BLACK, YELLOW);
      }
      height += 15;
      t = t->next;
    }
  }

}

void joystickUpDown(){ //obs�uga joystick w do� i do g�ry
  if((PIOA_PDSR & JOY_UP)==0)/ Gorna pozycja joysticka
  {
    if(menu_cursor > 0) // Jezeli kursor nie jest na pierwszym elemencie danego menu
    {
      menuPoprz(); // Przestaw kursor na poprzedni element
    }
    odswInt();
  }
  if((PIOA_PDSR & JOY_DOWN)==0)  // Dolna pozycjajoysticka
  {
    if(menu_cursor < 2) // Jezeli kursor nie jest na ostatnim elemencie danego menu
    {
      menuNast(); // Przestaw kursor na nastepny element
    }
    lcd_row_pos = menu_cursor; // Nr pozycji menu na LCD zgodny z pozycja kursora
    Delaya(1000000);//opoznienie
  }
}

void menuNast(void) { // Przechodzenie na kolejny element 
  if (currentPointer->next) // Sprawdzenie czy istnieje nastepny wezel
  {
    currentPointer = currentPointer->next; // Przypisanie adresu wezla do biezacego wskaznika
    menu_cursor++; // inkrementacja pozycji kursora
  }
  odswInt();// Odnswiezanie interfejsu
}

void menuPoprz(void) { // Przechodzenie na poprzedni element
  currentPointer = currentPointer->prev; // Przestawienie biezacego wskaznika na poprzedni wezel
  if (menu_cursor)// Jesli to nie jest pierwszy element menu...
  {
    menu_cursor--; // ...to dekrementuj pozycje kursora
  }

  odswInt();// Odnswiezanie interfejsu
}

void menuWejs(void) {//funkcja wchodzenia w podmenu 
  if ((PIOB_PDSR & SW_1)==0){ // Po nacisnieciu przycisku SW_1
    if(currentPointer->child){ // Sprawdzenie czy istnieje podmenu
      currentPointer = currentPointer->child; // Przestawienie wskaznika
      lcd_row_pos_level_1 = 0;// Ustawienie poczatkowej pozycji menu
      if(tempIndex==0){ // Jesli zmienna pomocnicza wyzerowana
        lcd_row_pos_level_1 = menu_cursor;// Ustawienie pozycji w podmenu zgodnie z kursorem
        tempIndex++; // Inkrementacja zmiennej pomocniczej
      }
      menu_cursor=0; // Ustawienie kursora w pozycji poczatkowej
      odswInt(); // Odnswiezanie interfejsu
      Delaya(100000); // Opoznienie
    }
  }
}

void menuWyjsc(void) { //funkcja wychodzenia z podmenu
  if ((PIOB_PDSR & SW_2)==0){ // Po nacisnieciu przycisku SW_2
    if(currentPointer->parent){// Sprawdzenie czy istnieje nadrzedne
      currentPointer = currentPointer->parent; // Przestawienie wskaznika
      if(tempIndex != 0) // Jesli zmienna pomocnicza nie jest wyzerowana
      {
        tempIndex = 0;// Ustaw zmienna w pozycje poczatkowa
        menu_cursor = lcd_row_pos_level_1; // Przestaw kursor zgodnie z pozycja w podmenu
      }
      odswInt();// Odnswiezanie interfejsu
      Delaya(100000); // Opoznienie
    }
  }
}


int main (){

  menu_cursor = 0; // pozycja przy inicjalizacji
  PMC_PCER=PMC_PCER_PIOA; // wlaczeniu kontrolera PIOA
  PMC_PCER=PMC_PCER_PIOB;// wlaczeniu kontrolera PIOB
  InitLCD(); // Inicjalizacja ekranu LCD
  SetContrast(30); // Ustawienie kontrastu
  LCDClearScreen(); // Wyczyszczenie ekranu

  pokazInt();

  while (1)
  {
    joystickUpDown();
    menuWejs();
    menuWyjsc();
  }
  return 0;
}
