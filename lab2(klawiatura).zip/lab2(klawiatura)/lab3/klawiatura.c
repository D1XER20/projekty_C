#include <avr/io.h>
#define F_CPU 8000000L
#include "klawiatura.h"

uint8_t read()
{
	uint8_t kolumna;
	uint8_t wiersz;
	uint8_t key_wiersz;
	uint8_t num_klaw;
	for(kolumna =0; kolumna < 4; kolumna++)
	{
		SW_PORT = ~(1<<(kolumna+4)) & SW_PORT;
		key_wiersz = SW_PIN | 0xF0;
		SW_PORT = 0xFF;
		if(key_wiersz !=0xFF)
		{
			wiersz = 0;
			key_wiersz = ~ key_wiersz;
			while (wiersz<4 && key_wiersz != 1<<wiersz)
			{
				wiersz++;
			}
			num_klaw = 4*wiersz + kolumna +1;
			return num_klaw;
		}
	}
	return 0;
}