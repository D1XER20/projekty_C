#ifndef KLAWIATURA_H_
#define KLAWIATURA_H_

#define SW_DDR DDRA
#define SW_PORT PORTA
#define SW_PIN PINA

#endif