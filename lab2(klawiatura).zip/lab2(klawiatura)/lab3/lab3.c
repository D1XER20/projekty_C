#include <avr/io.h>
#define F_CPU 8000000L
#include "klawiatura.h"

int main(void)
{
	DDRA = 0xF0;
	PORTA = 0xFF;
	DDRB = 0xFF;
    while(1)
    {
		PORTB = read();
    }
}